import Game from "./game/game.jsx";

function App() {


  return (
    <div className="App">
      <Game/>
    </div>
  )
}

export default App
